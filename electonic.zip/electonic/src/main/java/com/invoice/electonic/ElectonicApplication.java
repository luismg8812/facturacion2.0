package com.invoice.electonic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectonicApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectonicApplication.class, args);
	}
}
